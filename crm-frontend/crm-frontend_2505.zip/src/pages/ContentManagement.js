import React, { useState, useEffect, useMemo, useContext, useCallback, useRef } from 'react';
import { ThemeContext } from '../contexts/ThemeContext';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  TextField,
  Button,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Snackbar,
  CircularProgress,
  Tabs,
  Tab,
  Tooltip,
  InputAdornment,
  Menu,
  ListItemText,
  ListItemIcon,
  Divider,
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  ChevronLeft,
  ChevronRight,
  Today as TodayIcon,
  ViewList as ViewListIcon,
  CalendarMonth as CalendarMonthIcon,
  Search as SearchIcon,
  FilterList as FilterListIcon,
  Download as DownloadIcon,
  Close as CloseIcon,
  Person as PersonIcon,
  Business as BusinessIcon,
  CalendarToday as CalendarTodayIcon,
} from '@mui/icons-material';
import {
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  addDays,
  addMonths,
  subMonths,
  format,
  isSameMonth,
  isSameDay,
  isToday,
} from 'date-fns';
import html2canvas from 'html2canvas';
import contentEntryApi from '../api/contentEntryApi';
import api from '../api/axios';

const statusColors = {
  Planned: '#6366F1',
  Scheduled: '#F59E0B',
  Published: '#10B981',
  Missed: '#EF4444',
};

const contentTypeColors = {
  Reel: '#EC4899',
  Static: '#0EA5E9',
  Carousel: '#8B5CF6',
};

// Light pastel colors for calendar view based on content type
const calendarPastelColors = {
  Reel: { bg: '#FFF9C4', border: '#F9A825', text: '#7B6B00' },
  Static: { bg: '#E1F5FE', border: '#4FC3F7', text: '#01579B' },
  Carousel: { bg: '#F3E5F5', border: '#CE93D8', text: '#6A1B9A' },
};

const platformColors = {
  Instagram: '#E4405F',
  Facebook: '#1877F2',
  YouTube: '#FF0000',
};

const approvalColors = {
  Pending: '#F59E0B',
  Approved: '#10B981',
  Rejected: '#EF4444',
  'Revisions Needed': '#8B5CF6',
};

const CONTENT_TYPES = ['Reel', 'Static', 'Carousel'];
const PLATFORMS = ['Instagram', 'Facebook', 'YouTube'];
const STATUSES = ['Planned', 'Scheduled', 'Published', 'Missed'];
const APPROVAL_STATUSES = ['Pending', 'Approved', 'Rejected', 'Revisions Needed'];
const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const emptyForm = {
  date: new Date().toISOString().split('T')[0],
  clientName: '',
  contentType: '',
  postTitle: '',
  platform: '',
  description: '',
  referenceVideo: '',
  status: 'Planned',
  assignedSME: '',
  approvalStatus: '',
  remarks: '',
};

const ContentManagement = () => {
  const { accentColor } = useContext(ThemeContext);
  const primaryColor = accentColor?.primary || '#6366F1';
  const secondaryColor = accentColor?.secondary || '#818CF8';

  const [entries, setEntries] = useState([]);
  const [clients, setClients] = useState([]);
  const [smmUsers, setSmmUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [entryToDelete, setEntryToDelete] = useState(null);
  const [formData, setFormData] = useState(emptyForm);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [actionLoading, setActionLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Filters
  const [filterClient, setFilterClient] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterSME, setFilterSME] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');

  // Menu anchors for Notion-like filter dropdowns
  const [clientMenuAnchor, setClientMenuAnchor] = useState(null);
  const [smeMenuAnchor, setSmeMenuAnchor] = useState(null);
  const [statusMenuAnchor, setStatusMenuAnchor] = useState(null);
  const [dateMenuAnchor, setDateMenuAnchor] = useState(null);

  // Calendar state
  const [calendarDate, setCalendarDate] = useState(new Date());
  const calendarRef = useRef(null);

  // Download calendar as image
  const handleDownloadCalendar = async () => {
    if (!calendarRef.current) return;
    try {
      const canvas = await html2canvas(calendarRef.current, {
        backgroundColor: '#ffffff',
        scale: 2,
        useCORS: true,
      });
      const link = document.createElement('a');
      link.download = `Content-Calendar-${format(calendarDate, 'MMMM-yyyy')}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      showSnackbar('Calendar downloaded successfully');
    } catch (error) {
      console.error('Error downloading calendar:', error);
      showSnackbar('Failed to download calendar', 'error');
    }
  };

  const showSnackbar = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };

  // Fetch clients for dropdown (store full objects for SME lookup)
  const fetchClients = useCallback(async () => {
    try {
      const response = await api.get('/clients', { params: { limit: 1000 } });
      const data = response.data?.data || response.data || [];
      setClients(data.filter((c) => c.status === 'active'));
    } catch (error) {
      console.error('Error fetching clients:', error);
    }
  }, []);

  // Fetch SMM users for Assigned SME dropdown
  const fetchSMMUsers = useCallback(async () => {
    try {
      const response = await contentEntryApi.getSMMUsers();
      setSmmUsers(response.data || []);
    } catch (error) {
      console.error('Error fetching SMM users:', error);
    }
  }, []);

  // Fetch content entries
  const fetchEntries = useCallback(async () => {
    setLoading(true);
    try {
      const params = { limit: 1000 };
      if (filterClient) params.clientName = filterClient;
      if (filterStatus) params.status = filterStatus;
      if (filterSME) params.assignedSME = filterSME;
      if (filterDateFrom) params.dateFrom = filterDateFrom;
      if (filterDateTo) params.dateTo = filterDateTo;
      const response = await contentEntryApi.getContentEntries(params);
      setEntries(response.data || []);
    } catch (error) {
      console.error('Error fetching entries:', error);
      showSnackbar('Failed to fetch entries', 'error');
    } finally {
      setLoading(false);
    }
  }, [filterClient, filterStatus, filterSME, filterDateFrom, filterDateTo]);

  useEffect(() => {
    fetchClients();
    fetchSMMUsers();
  }, [fetchClients, fetchSMMUsers]);

  useEffect(() => {
    fetchEntries();
  }, [fetchEntries]);

  // Group entries by date for calendar
  const entriesByDate = useMemo(() => {
    const grouped = {};
    entries.forEach((entry) => {
      const dateKey = new Date(entry.date).toISOString().split('T')[0];
      if (!grouped[dateKey]) grouped[dateKey] = [];
      grouped[dateKey].push(entry);
    });
    return grouped;
  }, [entries]);

  // Filter entries for table view
  const filteredEntries = useMemo(() => {
    if (!searchQuery) return entries;
    const q = searchQuery.toLowerCase();
    return entries.filter(
      (e) =>
        e.postTitle?.toLowerCase().includes(q) ||
        e.clientName?.toLowerCase().includes(q) ||
        e.description?.toLowerCase().includes(q)
    );
  }, [entries, searchQuery]);

  // Calendar helpers
  const calendarDays = useMemo(() => {
    const monthStart = startOfMonth(calendarDate);
    const monthEnd = endOfMonth(calendarDate);
    const start = startOfWeek(monthStart);
    const end = endOfWeek(monthEnd);

    const days = [];
    let day = start;
    while (day <= end) {
      days.push(day);
      day = addDays(day, 1);
    }
    return days;
  }, [calendarDate]);

  // Dialog handlers
  const handleOpenDialog = (entry = null, prefilledDate = null) => {
    if (entry) {
      setEditingEntry(entry);
      setFormData({
        date: new Date(entry.date).toISOString().split('T')[0],
        clientName: entry.clientName || '',
        contentType: entry.contentType || '',
        postTitle: entry.postTitle || '',
        platform: entry.platform || '',
        description: entry.description || '',
        referenceVideo: entry.referenceVideo || '',
        status: entry.status || 'Planned',
        assignedSME: entry.assignedSME || '',
        approvalStatus: entry.approvalStatus || '',
        remarks: entry.remarks || '',
      });
    } else {
      setEditingEntry(null);
      setFormData({
        ...emptyForm,
        date: prefilledDate || new Date().toISOString().split('T')[0],
      });
    }
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingEntry(null);
    setFormData(emptyForm);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    if (name === 'clientName') {
      // Auto-fill Assigned SME from client's assigned SME
      const client = clients.find((c) => c.clientName === value);
      setFormData((prev) => ({
        ...prev,
        clientName: value,
        assignedSME: client?.assignedSME || prev.assignedSME,
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async () => {
    if (!formData.date || !formData.clientName || !formData.contentType || !formData.postTitle || !formData.platform) {
      showSnackbar('Please fill in all required fields', 'error');
      return;
    }

    setActionLoading(true);
    try {
      if (editingEntry) {
        const response = await contentEntryApi.updateContentEntry(editingEntry._id, formData);
        setEntries((prev) => prev.map((e) => (e._id === editingEntry._id ? response.data : e)));
        showSnackbar('Entry updated successfully');
      } else {
        const response = await contentEntryApi.createContentEntry(formData);
        setEntries((prev) => [response.data, ...prev]);
        showSnackbar('Entry created successfully');
      }
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving entry:', error);
      showSnackbar(error.response?.data?.message || 'Failed to save entry', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteClick = (entry) => {
    setEntryToDelete(entry);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!entryToDelete) return;
    setActionLoading(true);
    try {
      await contentEntryApi.deleteContentEntry(entryToDelete._id);
      setEntries((prev) => prev.filter((e) => e._id !== entryToDelete._id));
      showSnackbar('Entry deleted successfully');
      setDeleteDialogOpen(false);
      setEntryToDelete(null);
    } catch (error) {
      console.error('Error deleting entry:', error);
      showSnackbar('Failed to delete entry', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Stats
  const totalEntries = entries.length;
  const publishedCount = entries.filter((e) => e.status === 'Published').length;
  const plannedCount = entries.filter((e) => e.status === 'Planned').length;
  const missedCount = entries.filter((e) => e.status === 'Missed').length;

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 2 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
            Content Management
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Plan and track social media content across clients and platforms
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => handleOpenDialog()}
          sx={{
            background: `linear-gradient(135deg, ${primaryColor} 0%, ${secondaryColor} 100%)`,
            '&:hover': {
              background: `linear-gradient(135deg, ${secondaryColor} 0%, ${primaryColor} 100%)`,
            },
          }}
        >
          Add Entry
        </Button>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        {[
          { label: 'Total Entries', value: totalEntries, color: primaryColor },
          { label: 'Published', value: publishedCount, color: '#10B981' },
          { label: 'Planned', value: plannedCount, color: '#6366F1' },
          { label: 'Missed', value: missedCount, color: '#EF4444' },
        ].map((stat) => (
          <Grid size={{ xs: 6, md: 3 }} key={stat.label}>
            <Card>
              <CardContent sx={{ py: 2, '&:last-child': { pb: 2 } }}>
                <Typography variant="body2" color="text.secondary">
                  {stat.label}
                </Typography>
                <Typography variant="h4" sx={{ fontWeight: 700, color: stat.color }}>
                  {stat.value}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Tabs */}
      <Box sx={{ mb: 3 }}>
        <Tabs
          value={activeTab}
          onChange={(_, v) => setActiveTab(v)}
          sx={{
            '& .MuiTab-root': { textTransform: 'none', fontWeight: 600 },
          }}
        >
          <Tab icon={<ViewListIcon />} iconPosition="start" label="Table View" />
          <Tab icon={<CalendarMonthIcon />} iconPosition="start" label="Calendar View" />
        </Tabs>
      </Box>

      {/* Tab 0: Table View */}
      {activeTab === 0 && (
        <Box>
          {/* Notion-like Filters */}
          <Box sx={{ mb: 2.5 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
              {/* Search */}
              <TextField
                size="small"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                sx={{
                  minWidth: 200,
                  '& .MuiOutlinedInput-root': {
                    borderRadius: 2,
                    bgcolor: 'background.paper',
                    height: 34,
                    fontSize: '0.85rem',
                  },
                }}
                slotProps={{
                  input: {
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon sx={{ fontSize: 18, color: 'text.disabled' }} />
                      </InputAdornment>
                    ),
                  },
                }}
              />

              <Divider orientation="vertical" flexItem sx={{ mx: 0.5 }} />

              {/* Client Filter Chip */}
              <Chip
                icon={<BusinessIcon sx={{ fontSize: 15 }} />}
                label={filterClient || 'Client'}
                size="small"
                variant={filterClient ? 'filled' : 'outlined'}
                onClick={(e) => setClientMenuAnchor(e.currentTarget)}
                onDelete={filterClient ? () => setFilterClient('') : undefined}
                deleteIcon={filterClient ? <CloseIcon sx={{ fontSize: 14 }} /> : undefined}
                sx={{
                  borderRadius: 1.5,
                  fontWeight: 500,
                  fontSize: '0.8rem',
                  height: 32,
                  bgcolor: filterClient ? `${primaryColor}14` : 'transparent',
                  borderColor: filterClient ? primaryColor : 'divider',
                  color: filterClient ? primaryColor : 'text.secondary',
                  cursor: 'pointer',
                  '&:hover': { bgcolor: `${primaryColor}1A` },
                }}
              />

              {/* SME Filter Chip */}
              <Chip
                icon={<PersonIcon sx={{ fontSize: 15 }} />}
                label={filterSME || 'SME'}
                size="small"
                variant={filterSME ? 'filled' : 'outlined'}
                onClick={(e) => setSmeMenuAnchor(e.currentTarget)}
                onDelete={filterSME ? () => setFilterSME('') : undefined}
                deleteIcon={filterSME ? <CloseIcon sx={{ fontSize: 14 }} /> : undefined}
                sx={{
                  borderRadius: 1.5,
                  fontWeight: 500,
                  fontSize: '0.8rem',
                  height: 32,
                  bgcolor: filterSME ? `${primaryColor}14` : 'transparent',
                  borderColor: filterSME ? primaryColor : 'divider',
                  color: filterSME ? primaryColor : 'text.secondary',
                  cursor: 'pointer',
                  '&:hover': { bgcolor: `${primaryColor}1A` },
                }}
              />

              {/* Date Filter Chip */}
              <Chip
                icon={<CalendarTodayIcon sx={{ fontSize: 15 }} />}
                label={
                  filterDateFrom && filterDateTo
                    ? `${filterDateFrom} — ${filterDateTo}`
                    : filterDateFrom
                      ? `From ${filterDateFrom}`
                      : filterDateTo
                        ? `To ${filterDateTo}`
                        : 'Date'
                }
                size="small"
                variant={filterDateFrom || filterDateTo ? 'filled' : 'outlined'}
                onClick={(e) => setDateMenuAnchor(e.currentTarget)}
                onDelete={filterDateFrom || filterDateTo ? () => { setFilterDateFrom(''); setFilterDateTo(''); } : undefined}
                deleteIcon={(filterDateFrom || filterDateTo) ? <CloseIcon sx={{ fontSize: 14 }} /> : undefined}
                sx={{
                  borderRadius: 1.5,
                  fontWeight: 500,
                  fontSize: '0.8rem',
                  height: 32,
                  bgcolor: (filterDateFrom || filterDateTo) ? `${primaryColor}14` : 'transparent',
                  borderColor: (filterDateFrom || filterDateTo) ? primaryColor : 'divider',
                  color: (filterDateFrom || filterDateTo) ? primaryColor : 'text.secondary',
                  cursor: 'pointer',
                  '&:hover': { bgcolor: `${primaryColor}1A` },
                }}
              />

              {/* Status Filter Chip */}
              <Chip
                icon={<FilterListIcon sx={{ fontSize: 15 }} />}
                label={filterStatus || 'Status'}
                size="small"
                variant={filterStatus ? 'filled' : 'outlined'}
                onClick={(e) => setStatusMenuAnchor(e.currentTarget)}
                onDelete={filterStatus ? () => setFilterStatus('') : undefined}
                deleteIcon={filterStatus ? <CloseIcon sx={{ fontSize: 14 }} /> : undefined}
                sx={{
                  borderRadius: 1.5,
                  fontWeight: 500,
                  fontSize: '0.8rem',
                  height: 32,
                  bgcolor: filterStatus ? (statusColors[filterStatus] || primaryColor) + '14' : 'transparent',
                  borderColor: filterStatus ? statusColors[filterStatus] || primaryColor : 'divider',
                  color: filterStatus ? statusColors[filterStatus] || primaryColor : 'text.secondary',
                  cursor: 'pointer',
                  '&:hover': { bgcolor: `${primaryColor}1A` },
                }}
              />

              {/* Clear All */}
              {(filterClient || filterSME || filterDateFrom || filterDateTo || filterStatus || searchQuery) && (
                <Chip
                  label="Clear all"
                  size="small"
                  variant="outlined"
                  onClick={() => {
                    setFilterClient('');
                    setFilterSME('');
                    setFilterDateFrom('');
                    setFilterDateTo('');
                    setFilterStatus('');
                    setSearchQuery('');
                  }}
                  sx={{
                    borderRadius: 1.5,
                    fontWeight: 500,
                    fontSize: '0.75rem',
                    height: 32,
                    borderColor: '#EF4444',
                    color: '#EF4444',
                    cursor: 'pointer',
                    '&:hover': { bgcolor: '#EF444414' },
                  }}
                />
              )}
            </Box>
          </Box>

          {/* Client Filter Menu */}
          <Menu
            anchorEl={clientMenuAnchor}
            open={Boolean(clientMenuAnchor)}
            onClose={() => setClientMenuAnchor(null)}
            slotProps={{ paper: { sx: { maxHeight: 320, minWidth: 200, borderRadius: 2 } } }}
          >
            <MenuItem
              selected={!filterClient}
              onClick={() => { setFilterClient(''); setClientMenuAnchor(null); }}
              sx={{ fontSize: '0.85rem' }}
            >
              <ListItemText>All Clients</ListItemText>
            </MenuItem>
            <Divider />
            {clients.map((c) => (
              <MenuItem
                key={c._id}
                selected={filterClient === c.clientName}
                onClick={() => { setFilterClient(c.clientName); setClientMenuAnchor(null); }}
                sx={{ fontSize: '0.85rem' }}
              >
                <ListItemText>{c.clientName}</ListItemText>
              </MenuItem>
            ))}
          </Menu>

          {/* SME Filter Menu */}
          <Menu
            anchorEl={smeMenuAnchor}
            open={Boolean(smeMenuAnchor)}
            onClose={() => setSmeMenuAnchor(null)}
            slotProps={{ paper: { sx: { maxHeight: 320, minWidth: 200, borderRadius: 2 } } }}
          >
            <MenuItem
              selected={!filterSME}
              onClick={() => { setFilterSME(''); setSmeMenuAnchor(null); }}
              sx={{ fontSize: '0.85rem' }}
            >
              <ListItemText>All SMEs</ListItemText>
            </MenuItem>
            <Divider />
            {smmUsers.map((u) => (
              <MenuItem
                key={u._id}
                selected={filterSME === u.name}
                onClick={() => { setFilterSME(u.name); setSmeMenuAnchor(null); }}
                sx={{ fontSize: '0.85rem' }}
              >
                <ListItemText>{u.name}{u.team ? ` (${u.team})` : ''}</ListItemText>
              </MenuItem>
            ))}
          </Menu>

          {/* Status Filter Menu */}
          <Menu
            anchorEl={statusMenuAnchor}
            open={Boolean(statusMenuAnchor)}
            onClose={() => setStatusMenuAnchor(null)}
            slotProps={{ paper: { sx: { maxHeight: 320, minWidth: 180, borderRadius: 2 } } }}
          >
            <MenuItem
              selected={!filterStatus}
              onClick={() => { setFilterStatus(''); setStatusMenuAnchor(null); }}
              sx={{ fontSize: '0.85rem' }}
            >
              <ListItemText>All Statuses</ListItemText>
            </MenuItem>
            <Divider />
            {STATUSES.map((s) => (
              <MenuItem
                key={s}
                selected={filterStatus === s}
                onClick={() => { setFilterStatus(s); setStatusMenuAnchor(null); }}
                sx={{ fontSize: '0.85rem' }}
              >
                <ListItemIcon>
                  <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: statusColors[s] }} />
                </ListItemIcon>
                <ListItemText>{s}</ListItemText>
              </MenuItem>
            ))}
          </Menu>

          {/* Date Filter Menu */}
          <Menu
            anchorEl={dateMenuAnchor}
            open={Boolean(dateMenuAnchor)}
            onClose={() => setDateMenuAnchor(null)}
            slotProps={{ paper: { sx: { p: 2, borderRadius: 2, minWidth: 260 } } }}
          >
            <Typography variant="subtitle2" sx={{ mb: 1.5, fontWeight: 600, color: 'text.secondary', fontSize: '0.8rem' }}>
              Filter by Date Range
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
              <TextField
                size="small"
                type="date"
                label="From"
                value={filterDateFrom}
                onChange={(e) => setFilterDateFrom(e.target.value)}
                InputLabelProps={{ shrink: true }}
                fullWidth
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1.5 } }}
              />
              <TextField
                size="small"
                type="date"
                label="To"
                value={filterDateTo}
                onChange={(e) => setFilterDateTo(e.target.value)}
                InputLabelProps={{ shrink: true }}
                fullWidth
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1.5 } }}
              />
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 0.5 }}>
                <Button
                  size="small"
                  onClick={() => { setFilterDateFrom(''); setFilterDateTo(''); }}
                  sx={{ fontSize: '0.75rem', color: 'text.secondary' }}
                >
                  Clear dates
                </Button>
                <Button
                  size="small"
                  variant="contained"
                  onClick={() => setDateMenuAnchor(null)}
                  sx={{
                    fontSize: '0.75rem',
                    borderRadius: 1.5,
                    background: `linear-gradient(135deg, ${primaryColor} 0%, ${secondaryColor} 100%)`,
                  }}
                >
                  Apply
                </Button>
              </Box>
            </Box>
          </Menu>

          {/* Table */}
          <Card elevation={0} sx={{ border: '1px solid', borderColor: 'divider' }}>
            <CardContent sx={{ p: 0 }}>
              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
                  <CircularProgress />
                </Box>
              ) : (
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow sx={{ bgcolor: 'action.hover' }}>
                        <TableCell sx={{ fontWeight: 700 }}>Posting Date</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Client</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Type</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Post Title</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Platform</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Assigned SME</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Description</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Reference</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Approval Status</TableCell>
                        <TableCell sx={{ fontWeight: 700 }}>Remarks</TableCell>
                        <TableCell sx={{ fontWeight: 700, width: 100 }}>Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {filteredEntries.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={12} align="center" sx={{ py: 4 }}>
                            <Typography color="text.secondary">
                              No content entries found. Click "Add Entry" to get started.
                            </Typography>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredEntries.map((entry) => (
                          <TableRow key={entry._id} hover>
                            <TableCell sx={{ whiteSpace: 'nowrap' }}>
                              {new Date(entry.date).toLocaleDateString('en-IN', {
                                day: '2-digit',
                                month: 'short',
                                year: 'numeric',
                              })}
                            </TableCell>
                            <TableCell sx={{ fontWeight: 600 }}>{entry.clientName}</TableCell>
                            <TableCell>
                              <Chip
                                label={entry.contentType}
                                size="small"
                                sx={{
                                  bgcolor: contentTypeColors[entry.contentType] + '18',
                                  color: contentTypeColors[entry.contentType],
                                  fontWeight: 600,
                                }}
                              />
                            </TableCell>
                            <TableCell sx={{ maxWidth: 200 }}>
                              <Typography variant="body2" noWrap>
                                {entry.postTitle}
                              </Typography>
                            </TableCell>
                            <TableCell>
                              <Chip
                                label={entry.platform}
                                size="small"
                                sx={{
                                  bgcolor: platformColors[entry.platform] + '18',
                                  color: platformColors[entry.platform],
                                  fontWeight: 600,
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              <Typography variant="body2" noWrap>
                                {entry.assignedSME || '-'}
                              </Typography>
                            </TableCell>
                            <TableCell sx={{ maxWidth: 180 }}>
                              <Typography variant="body2" noWrap color="text.secondary">
                                {entry.description || '-'}
                              </Typography>
                            </TableCell>
                            <TableCell sx={{ maxWidth: 150 }}>
                              {entry.referenceVideo ? (
                                entry.referenceVideo.startsWith('http') ? (
                                  <Typography
                                    variant="body2"
                                    component="a"
                                    href={entry.referenceVideo}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    sx={{ color: primaryColor, textDecoration: 'none', '&:hover': { textDecoration: 'underline' } }}
                                    noWrap
                                  >
                                    View Link
                                  </Typography>
                                ) : (
                                  <Typography variant="body2" noWrap color="text.secondary">
                                    {entry.referenceVideo}
                                  </Typography>
                                )
                              ) : (
                                '-'
                              )}
                            </TableCell>
                            <TableCell>
                              <Chip
                                label={entry.status}
                                size="small"
                                sx={{
                                  bgcolor: statusColors[entry.status] + '18',
                                  color: statusColors[entry.status],
                                  fontWeight: 600,
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              {entry.approvalStatus ? (
                                <Chip
                                  label={entry.approvalStatus}
                                  size="small"
                                  sx={{
                                    bgcolor: (approvalColors[entry.approvalStatus] || '#999') + '18',
                                    color: approvalColors[entry.approvalStatus] || '#999',
                                    fontWeight: 600,
                                  }}
                                />
                              ) : (
                                '-'
                              )}
                            </TableCell>
                            <TableCell sx={{ maxWidth: 150 }}>
                              <Typography variant="body2" noWrap color="text.secondary">
                                {entry.remarks || '-'}
                              </Typography>
                            </TableCell>
                            <TableCell>
                              <Box sx={{ display: 'flex', gap: 0.5 }}>
                                <Tooltip title="Edit">
                                  <IconButton size="small" onClick={() => handleOpenDialog(entry)} color="primary">
                                    <EditIcon fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                                <Tooltip title="Delete">
                                  <IconButton size="small" onClick={() => handleDeleteClick(entry)} color="error">
                                    <DeleteIcon fontSize="small" />
                                  </IconButton>
                                </Tooltip>
                              </Box>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </CardContent>
          </Card>
        </Box>
      )}

      {/* Tab 1: Calendar View */}
      {activeTab === 1 && (
        <Card>
          <CardContent>
            {/* Calendar Header */}
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <IconButton onClick={() => setCalendarDate((d) => subMonths(d, 1))}>
                  <ChevronLeft />
                </IconButton>
                <Typography variant="h5" sx={{ fontWeight: 700, minWidth: 200, textAlign: 'center' }}>
                  {format(calendarDate, 'MMMM yyyy')}
                </Typography>
                <IconButton onClick={() => setCalendarDate((d) => addMonths(d, 1))}>
                  <ChevronRight />
                </IconButton>
              </Box>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button
                  variant="outlined"
                  size="small"
                  startIcon={<TodayIcon />}
                  onClick={() => setCalendarDate(new Date())}
                >
                  Today
                </Button>
                <Button
                  variant="outlined"
                  size="small"
                  startIcon={<DownloadIcon />}
                  onClick={handleDownloadCalendar}
                  sx={{ color: primaryColor, borderColor: primaryColor }}
                >
                  Download
                </Button>
              </Box>
            </Box>

            {/* Downloadable calendar area */}
            <Box ref={calendarRef} sx={{ bgcolor: 'background.paper' }}>
            {/* Day Headers */}
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: '1px',
                bgcolor: 'divider',
                border: '1px solid',
                borderColor: 'divider',
                borderBottom: 'none',
              }}
            >
              {DAY_NAMES.map((day) => (
                <Box
                  key={day}
                  sx={{
                    py: 1,
                    textAlign: 'center',
                    bgcolor: 'action.hover',
                    fontWeight: 700,
                  }}
                >
                  <Typography variant="body2" sx={{ fontWeight: 700 }}>
                    {day}
                  </Typography>
                </Box>
              ))}
            </Box>

            {/* Calendar Grid */}
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(7, 1fr)',
                gap: '1px',
                bgcolor: 'divider',
                border: '1px solid',
                borderColor: 'divider',
              }}
            >
              {calendarDays.map((day, idx) => {
                const dateKey = format(day, 'yyyy-MM-dd');
                const dayEntries = entriesByDate[dateKey] || [];
                const isCurrentMonth = isSameMonth(day, calendarDate);
                const isCurrentDay = isToday(day);

                // Determine cell background from first entry's content type
                const cellPastel = dayEntries.length > 0
                  ? calendarPastelColors[dayEntries[0].contentType] || { bg: '#F5F5F5', border: '#BDBDBD', text: '#424242' }
                  : null;

                return (
                  <Box
                    key={idx}
                    sx={{
                      minHeight: 110,
                      p: 0.75,
                      bgcolor: cellPastel
                        ? cellPastel.bg
                        : isCurrentDay
                          ? `${primaryColor}08`
                          : isCurrentMonth
                            ? 'background.paper'
                            : 'action.hover',
                      cursor: 'pointer',
                      transition: 'background-color 0.15s',
                      '&:hover': { bgcolor: cellPastel ? `${cellPastel.bg}CC` : `${primaryColor}12` },
                      display: 'flex',
                      flexDirection: 'column',
                    }}
                    onClick={() => handleOpenDialog(null, dateKey)}
                  >
                    {/* Date Number */}
                    <Typography
                      variant="caption"
                      sx={{
                        fontWeight: isCurrentDay ? 700 : 500,
                        color: isCurrentDay
                          ? 'white'
                          : isCurrentMonth
                            ? 'text.primary'
                            : 'text.disabled',
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: 24,
                        height: 24,
                        borderRadius: '50%',
                        bgcolor: isCurrentDay ? primaryColor : 'transparent',
                        mb: 0.5,
                      }}
                    >
                      {format(day, 'd')}
                    </Typography>

                    {/* Entries */}
                    <Box sx={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                      {dayEntries.slice(0, 3).map((entry) => (
                        <Box
                          key={entry._id}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenDialog(entry);
                          }}
                          sx={{
                            mb: 0.5,
                            px: 0.5,
                            py: 0.25,
                            borderRadius: 0.5,
                            cursor: 'pointer',
                            '&:hover': { bgcolor: 'rgba(255,255,255,0.5)' },
                            overflow: 'hidden',
                            textAlign: 'center',
                            width: '100%',
                          }}
                        >
                          <Typography
                            sx={{
                              fontSize: '0.75rem',
                              fontWeight: 600,
                              color: '#212121',
                              display: 'block',
                              lineHeight: 1.4,
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                            }}
                          >
                            {entry.postTitle}
                          </Typography>
                          <Typography
                            sx={{
                              fontSize: '0.65rem',
                              fontWeight: 500,
                              color: statusColors[entry.status],
                              display: 'block',
                              lineHeight: 1.3,
                            }}
                          >
                            {entry.status}
                          </Typography>
                        </Box>
                      ))}
                      {dayEntries.length > 3 && (
                        <Typography variant="caption" sx={{ fontSize: '0.6rem', color: 'text.secondary', pl: 0.5 }}>
                          +{dayEntries.length - 3} more
                        </Typography>
                      )}
                    </Box>
                  </Box>
                );
              })}
            </Box>
            </Box>
            {/* End downloadable calendar area */}
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ fontWeight: 600 }}>
          {editingEntry ? 'Edit Content Entry' : 'Add Content Entry'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 0.5 }}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                type="date"
                label="Date"
                name="date"
                value={formData.date}
                onChange={handleFormChange}
                required
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                select
                label="Client Name"
                name="clientName"
                value={formData.clientName}
                onChange={handleFormChange}
                required
              >
                {clients.map((c) => (
                  <MenuItem key={c._id} value={c.clientName}>
                    {c.clientName}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                select
                label="Content Type"
                name="contentType"
                value={formData.contentType}
                onChange={handleFormChange}
                required
              >
                {CONTENT_TYPES.map((t) => (
                  <MenuItem key={t} value={t}>
                    {t}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                label="Post Title"
                name="postTitle"
                value={formData.postTitle}
                onChange={handleFormChange}
                required
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                select
                label="Platform"
                name="platform"
                value={formData.platform}
                onChange={handleFormChange}
                required
              >
                {PLATFORMS.map((p) => (
                  <MenuItem key={p} value={p}>
                    {p}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                select
                label="Status"
                name="status"
                value={formData.status}
                onChange={handleFormChange}
                required
              >
                {STATUSES.map((s) => (
                  <MenuItem key={s} value={s}>
                    {s}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Description"
                name="description"
                value={formData.description}
                onChange={handleFormChange}
                multiline
                rows={2}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                select
                label="Assigned SME"
                name="assignedSME"
                value={formData.assignedSME}
                onChange={handleFormChange}
              >
                <MenuItem value="">None</MenuItem>
                {smmUsers.map((u) => (
                  <MenuItem key={u._id} value={u.name}>
                    {u.name}{u.team ? ` (${u.team})` : ''}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <TextField
                fullWidth
                select
                label="Approval Status (from Client)"
                name="approvalStatus"
                value={formData.approvalStatus}
                onChange={handleFormChange}
              >
                <MenuItem value="">Not Set</MenuItem>
                {APPROVAL_STATUSES.map((s) => (
                  <MenuItem key={s} value={s}>
                    {s}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Reference Video (URL or text)"
                name="referenceVideo"
                value={formData.referenceVideo}
                onChange={handleFormChange}
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <TextField
                fullWidth
                label="Remarks"
                name="remarks"
                value={formData.remarks}
                onChange={handleFormChange}
                multiline
                rows={2}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={actionLoading}
            sx={{
              background: `linear-gradient(135deg, ${primaryColor} 0%, ${secondaryColor} 100%)`,
              '&:hover': {
                background: `linear-gradient(135deg, ${secondaryColor} 0%, ${primaryColor} 100%)`,
              },
            }}
          >
            {actionLoading ? <CircularProgress size={24} /> : editingEntry ? 'Update' : 'Add Entry'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete <strong>{entryToDelete?.postTitle}</strong>? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDeleteConfirm} disabled={actionLoading}>
            {actionLoading ? <CircularProgress size={24} /> : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ContentManagement;
